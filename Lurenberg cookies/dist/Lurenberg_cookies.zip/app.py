from flask import Flask, request, make_response, render_template
import hashlib
import base64
import pickle
import os

app = Flask(__name__)
SECRET_KEY = os.environ.get('SECRET_KEY')

def sign_data(data):
    return hashlib.sha256((data + SECRET_KEY).encode()).hexdigest()

def serialize_data(data):
    return base64.b64encode(pickle.dumps(data)).decode()

def deserialize_data(data):
    return pickle.loads(base64.b64decode(data))


@app.route('/')
def index():
    user_data = request.cookies.get('data')
    signature = request.cookies.get('signature')
    
    if user_data and signature:
        if hashlib.sha256((user_data + SECRET_KEY).encode()).hexdigest() == signature:
            result = deserialize_data(user_data)
            return render_template('success.html', result=result)
        else:
            return render_template('error.html', message="Signature invalide!"), 403
    else:
        initial_data = "Safe data"
        serialized_data = serialize_data(initial_data)
        signed_data = sign_data(serialized_data)
        response = make_response(render_template('welcome.html'))
        response.set_cookie('data', serialized_data)
        response.set_cookie('signature', signed_data)
        return response


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
